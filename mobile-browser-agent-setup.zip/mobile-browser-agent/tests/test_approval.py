import importlib.util
from pathlib import Path
import unittest

path = Path(__file__).resolve().parents[1] / "overlay/src/controller/approval_policy.py"
spec = importlib.util.spec_from_file_location("approval_policy", path)
policy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy)


class ApprovalTests(unittest.TestCase):
    def test_public_smoke_navigation(self):
        self.assertEqual(policy.decision("go_to_url", {"url": "https://example.com/"}, "about:blank"), "allow")
        self.assertEqual(policy.decision("click_element", {"index": 1}, "https://example.com/", "https://www.iana.org/help/example-domains"), "allow")

    def test_domain_and_scheme_confusion_fail_closed(self):
        for url in ["https://example.com.evil.test/", "https://evil.test/?next=example.com",
                    "https://example.com@evil.test/", "http://example.com/", "javascript:alert(1)",
                    "https://example.com/?delete=1", "https://example.com:444/", None]:
            with self.subTest(url=url):
                self.assertFalse(policy.test_url(url))

    def test_sensitive_actions_require_approval(self):
        for action in ["click_element", "input_text", "go_to_url", "open_tab", "search_google", "unknown_new_action"]:
            with self.subTest(action=action):
                self.assertEqual(policy.decision(action, {"text": "Buy now", "url": "https://shop.test/pay"}, "https://shop.test/"), "approve")

    def test_click_without_proven_link_is_not_auto_approved(self):
        self.assertEqual(policy.decision("click_element", {"index": 1}, "https://example.com/"), "approve")

    def test_upload_and_keyboard_shortcuts_require_manual_control(self):
        for action in ["upload_file", "send_keys", "drag_drop", "mcp.shell.run"]:
            self.assertEqual(policy.decision(action, {}, "https://example.com/"), "manual")

    def test_missing_denied_and_timeout_responses_never_approve(self):
        for response in [None, {}, {"response": None}, {"response": ""}, {"response": "yes"},
                         {"response": "Timeout: User did not respond."}, {"response": "DO NOT APPROVE"}]:
            self.assertFalse(policy.approved(response))
        self.assertTrue(policy.approved({"response": "APPROVE"}))


if __name__ == "__main__":
    unittest.main()
