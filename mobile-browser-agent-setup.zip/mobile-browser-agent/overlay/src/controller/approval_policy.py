"""Fail closed before actions that may change a real website.

Only navigation and link clicks on the two public smoke-test domains are
automatic. Other clicks, typing and unknown actions each need one approval.
This deliberately avoids pretending a small LLM can classify every payment.
"""
import json
from urllib.parse import urlsplit

TEST_HOSTS = frozenset({"example.com", "www.iana.org"})
READ_ACTIONS = frozenset({
    "done", "extract_content", "scroll_down", "scroll_up",
    "scroll_to_text", "switch_tab", "close_tab", "wait",
})
MANUAL_ACTIONS = frozenset({"upload_file", "drag_drop", "send_keys"})


def test_url(url):
    try:
        parsed = urlsplit(url)
        return (parsed.scheme == "https" and parsed.hostname in TEST_HOSTS
                and parsed.port in (None, 443) and not parsed.username
                and not parsed.password and not parsed.query)
    except (ValueError, TypeError):
        return False


def decision(action, params, current_url, target_url=None):
    if action == "ask_for_assistant" or action in READ_ACTIONS:
        return "allow"
    if action in MANUAL_ACTIONS or action.startswith("mcp"):
        return "manual"
    if action in {"go_to_url", "open_tab"} and test_url(params.get("url")):
        return "allow"
    if action == "click_element" and test_url(current_url) and test_url(target_url):
        return "allow"
    return "approve"


def approval_message(action, params, current_url):
    payload = json.dumps(params, ensure_ascii=False)
    return (
        f"Approve ONE action?\nPage: {current_url}\nAction: {action}\n"
        f"Parameters: {payload}\nInspect the live browser before approving. "
        "For CAPTCHA, login, MFA, identity or age checks, operate the live browser yourself. "
        "Reply exactly APPROVE to run this action once; anything else denies it."
    )


def approved(response):
    value = response.get("response") if isinstance(response, dict) else None
    return isinstance(value, str) and value.strip() == "APPROVE"
