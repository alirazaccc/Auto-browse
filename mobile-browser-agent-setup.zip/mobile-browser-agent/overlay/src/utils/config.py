import os

model_names = {"ollama": list(dict.fromkeys([
    os.getenv("OLLAMA_MODEL", "qwen2.5:3b"),
    "qwen2.5:1.5b", "qwen2.5:3b", "gemma3:1b",
]))}
PROVIDER_DISPLAY_NAMES = {"ollama": "Local Ollama"}
