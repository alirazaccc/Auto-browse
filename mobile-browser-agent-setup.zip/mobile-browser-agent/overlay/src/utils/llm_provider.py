"""Only the local Ollama service is accepted; no API-key fallback."""
import os
from langchain_ollama import ChatOllama


def get_llm_model(provider: str, **kwargs):
    if provider != "ollama":
        raise ValueError("This installation supports local Ollama only.")
    endpoint = os.environ.get("OLLAMA_ENDPOINT", "http://ollama:11434")
    requested_endpoint = kwargs.get("base_url")
    if requested_endpoint and requested_endpoint.rstrip("/") != endpoint.rstrip("/"):
        raise ValueError("The model endpoint is fixed to this server's Ollama service.")
    model = kwargs.get("model_name") or os.environ.get("OLLAMA_MODEL", "qwen2.5:3b")
    if "cloud" in model.lower() or "/" in model:
        raise ValueError("Use a downloaded local model tag, not a cloud model.")
    return ChatOllama(
        model=model,
        base_url=endpoint,
        temperature=0,
        num_ctx=min(int(kwargs.get("num_ctx") or 4096), 8192),
        num_predict=768,
        num_thread=int(os.environ.get("OLLAMA_NUM_THREAD", "2")),
        keep_alive="5m",
        client_kwargs={"timeout": 300.0},
    )
