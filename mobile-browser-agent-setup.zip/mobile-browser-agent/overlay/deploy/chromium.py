"""A long-lived profile; Browser-Use attaches through loopback CDP."""
import asyncio
from pathlib import Path
from playwright.async_api import async_playwright


async def main():
    # Supervisor starts Xvfb first; wait for its local socket, not a fixed sleep.
    for _ in range(100):
        if Path("/tmp/.X11-unix/X99").exists():
            break
        await asyncio.sleep(0.1)
    else:
        raise RuntimeError("Xvfb did not start")
    async with async_playwright() as playwright:
        context = await playwright.chromium.launch_persistent_context(
            "/data/profile", headless=False, chromium_sandbox=False,
            viewport={"width": 1280, "height": 900},
            args=["--remote-debugging-address=127.0.0.1", "--remote-debugging-port=9222",
                  "--no-first-run", "--no-default-browser-check", "--window-size=1280,900"],
        )
        closed = asyncio.Event()
        context.on("close", lambda _: closed.set())
        await closed.wait()


if __name__ == "__main__":
    asyncio.run(main())
