"""A real local inference and structured-output probe; not an agent benchmark."""
import json
import os
import time
from urllib.request import Request, urlopen

model = os.getenv("OLLAMA_MODEL", "qwen2.5:3b")
payload = {
    "model": model, "stream": False, "format": "json",
    "prompt": 'Return only JSON with the key "page_title" and the value "Example Domain".',
    "options": {"temperature": 0, "num_ctx": 4096, "num_predict": 100},
}
started = time.monotonic()
request = Request(os.environ["OLLAMA_ENDPOINT"] + "/api/generate",
                  data=json.dumps(payload).encode(), headers={"Content-Type": "application/json"})
with urlopen(request, timeout=300) as response:
    result = json.load(response)
answer = json.loads(result["response"])
if answer != {"page_title": "Example Domain"}:
    raise SystemExit("FAIL: local model did not produce the requested JSON")
print(json.dumps({"model": model, "json_probe": "PASS", "seconds": round(time.monotonic() - started, 2)}))
