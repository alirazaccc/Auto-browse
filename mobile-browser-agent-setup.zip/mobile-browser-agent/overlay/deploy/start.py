"""Initialize private VNC credentials and run supervised services as non-root."""
import os
from pathlib import Path
import subprocess

for directory in ("/data/profile", "/data/work", "/tmp/agent-vnc"):
    Path(directory).mkdir(parents=True, exist_ok=True)
password = Path("/run/secrets/vnc_password").read_text().strip()
if len(password) != 8:
    raise SystemExit("VNC secret must contain exactly eight random characters; run init.")
subprocess.run(["x11vnc", "-storepasswd", password, "/tmp/agent-vnc/passwd"],
               check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
os.chmod("/tmp/agent-vnc/passwd", 0o600)
os.execvp("supervisord", ["supervisord", "-c", "/app/deploy/supervisord.conf"])
