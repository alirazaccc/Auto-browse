import socket
from urllib.request import urlopen

for url in ("http://127.0.0.1:7788/", "http://127.0.0.1:6080/vnc.html",
            "http://127.0.0.1:9222/json/version"):
    with urlopen(url, timeout=3) as response:
        if response.status != 200:
            raise SystemExit(f"Unhealthy: {url}")
with socket.create_connection(("127.0.0.1", 5901), timeout=2) as connection:
    if not connection.recv(12).startswith(b"RFB "):
        raise SystemExit("VNC handshake failed")
