# Mobile browser agent — development setup

Status, 8 September 2026: setup code is prepared. The upstream adaptations apply
successfully and the approval-policy tests pass. No cloud server has been created,
no Docker image has been built, and no end-to-end mobile agent task has passed yet.
The current workspace has no Docker daemon and dependency downloads were unavailable.
GitHub Codespaces is at its sign-in page. Account access is the next deployment step.

This is a supervised, single-user Browser-Use WebUI prototype with local Ollama,
Playwright Chromium, a persistent browser profile and noVNC. Android uses one
authenticated HTTPS address supplied by the hosting environment. No paid model API
is configured. The application accepts only Ollama, and Ollama cloud features are
disabled. Browser-Use itself has transitive provider SDK packages; their presence
does not require an API key or make a hosted model call.

## Host selection

Use GitHub Codespaces only to develop and test this repository. Its terms prohibit
production-facing applications and activities unrelated to project development or
testing. This applies even to short daily sessions. It is not the permanent home
for a general personal automation service.

A personal GitHub Free account includes 120 core-hours/month and 15 GB-month of
storage. A 2-core machine consumes 2 core-hours per clock hour: at most 60 running
hours/month before other limits. Model files, Docker images and stopped Codespaces
consume storage allowance. Physical free disk and the monthly storage budget are
different. Without a valid payment method, exhausted included usage blocks further
use until reset. Check the account's actual remaining allowances before creation;
do not enable paid overages, add payment details or create extra accounts.

Official sources:
- https://docs.github.com/en/billing/concepts/product-billing/github-codespaces
- https://docs.github.com/en/site-policy/github-terms/github-terms-for-additional-products-and-features#codespaces
- https://docs.github.com/en/codespaces/reference/security-in-github-codespaces

## Models to compare on the actual server

Download size is not runtime RAM. The RAM choices below are provisional engineering
estimates for the whole browser stack, not measured throughput or success rates.
Download one model at a time to conserve storage.

| Model | Approximate download | Initial use |
| --- | --- | --- |
| Gemma 3 1B | 815 MB | Very small text model for comparison; JSON/action reliability must be tested |
| Qwen 2.5 1.5B | 986 MB | Lightweight fallback around 6 GB total host RAM |
| Qwen 2.5 3B | 1.9 GB | Provisional baseline for a 2-core, 8 GB host; Qwen research license applies |
| Qwen 3.5 2B | 2.7 GB | Later vision-capable comparison, after baseline tests and RAM measurement |

The initial agent reads the visible page DOM, with vision off, temperature zero,
4096-token Ollama context and one action per step. This reduces CPU/RAM demand.
Gemma 3 1B is text-only. The small-model baseline may fail complex sites; successful
chat output alone is not proof that Browser-Use can complete a task.

Sources: https://ollama.com/library/gemma3:1b,
https://ollama.com/library/qwen2.5:1.5b,
https://ollama.com/library/qwen2.5:3b,
https://ollama.com/library/qwen3.5:2b.
Ollama local-only mode: https://docs.ollama.com/faq#how-do-i-disable-ollama-cloud-features

## Start in an approved development environment

Put these files at the root of a repository owned by your existing GitHub account.
Use a private repository; public publishing requires a separate confirmation.
Create a 2-core Codespace after checking free quota. The supplied devcontainer
configures Docker. Do not install a VPN or create extra accounts to get capacity.

Run as the normal user with Docker access:

```bash
python3 scripts/manage.py check
python3 scripts/manage.py init
python3 scripts/manage.py start
python3 scripts/manage.py smoke
```

Initialization creates random web/VNC credentials in `.secrets`, mode 0600, and
chooses a provisional model from actual available RAM. It refuses to replace
existing settings. The first start downloads Ollama, the selected model, Python
dependencies and Chromium; this takes time and consumes Codespaces quota.

Inspect credentials only in your own terminal:

```bash
python3 scripts/manage.py credentials
```

In the Codespaces Ports panel, keep port 8080 **Private** and open its forwarded
HTTPS address. Sign into GitHub on Android, then the agent's separate web login.
Use **Open live browser** to open noVNC and supply its VNC password. noVNC's scale
mode adapts the desktop to the phone; its side toolbar provides keyboard controls.
Mobile rendering and touch interaction still need a real device check.

For another Linux server, the default port binds only to loopback. Supply an
authenticated HTTPS/private access route before mobile access. Do not change the
binding to a public interface merely to make the page reachable.

## Action approval and manual verification

Only harmless HTTPS navigation to example.com / www.iana.org and proven links
between these test domains run without an action approval. Read/scroll operations
are permitted. On other sites, every click, typing action, navigation or unknown
action asks for approval in chat. Reply exactly `APPROVE` for one action, or `DENY`.
Missing approval, timeout and a missing approval channel deny the action.

This intentionally conservative prototype does not rely on a small model to
classify every payment, deletion or publication. It does not enable unattended
real-world workflows. Uploads, keyboard shortcuts and MCP execution are disabled
or require manual browser control. Deep Research is disabled for this first test.
Complete logins, CAPTCHA, MFA, identity and age checks yourself in noVNC. Do not
type passwords or verification codes into the agent chat. No bypass helpers exist.

The deployment patch fixes the upstream approval callback's wrong state attribute
and allows a second UI request to deliver approval while the first task is waiting.
Stop remains available while waiting. These UI behaviours require runtime testing.

## Persistent sessions

Chromium runs continuously with `.local-state/browser/profile`; the agent attaches
to its existing context using loopback CDP. Settings, histories and downloads are
under `.local-state/browser/work`. Model files live under `.local-state/ollama`.
These bind mounts should survive container stop/start and image rebuilds while
the workspace exists. Verify cookies after a restart before relying on this.

A website can still expire a login or demand MFA. Deleting the Codespace or server
can remove its data. Back up the profile privately if needed; never commit browser
cookies, session profiles, credentials or task history to GitHub. They are excluded
from both Git and Docker build context.

```bash
python3 scripts/manage.py stop
```

Stopping containers preserves state. Stop the Codespace itself as well to stop
compute consumption; closing the browser tab does not immediately stop its VM.

## Required acceptance checks

`smoke` checks that the gateway returns 401 without login, probes WebUI/noVNC/CDP,
verifies a VNC handshake and performs a real local JSON generation. Those checks
have not run in a Docker host yet. Also check that unauthenticated `/live/vnc.html`
and the WebSocket path are rejected, and confirm the forwarded port is private.

In the mobile WebUI, run this harmless command:

> Open https://example.com/. Read its page title. Click its Learn more link to
> IANA, then report the new URL and page title. Do not sign in or submit any form.

Acceptance requires actual browser navigation visible in noVNC and an agent result
that matches it. Then manually set a harmless test-site cookie, restart containers
and confirm the cookie persists. Finally, test that a denied action never executes.

## Troubleshooting without losing data

```bash
python3 scripts/manage.py status
docker compose logs --tail=80 browser
docker compose logs --tail=80 ollama
docker compose logs --tail=80 gateway
```

Do not share logs without checking for task content. A model-load memory error calls
for the smaller Qwen tag in `.env`, then `start`; changing the WebUI dropdown does
not download a model. Keep vision off for Qwen 2.5 and Gemma 3 1B. If the local JSON
probe passes but agent output is invalid, inspect the error and adjust context or
model; do not add a paid API fallback. A pending CAPTCHA is for the user, not for
network/fingerprint changes. Do not automatically delete data or Docker volumes.

## Known limits before deployment approval

Docker build, dependency installation, model inference, actual approval UI, profile
reuse and mobile/noVNC interaction remain unverified. The WebUI is based on the
specific upstream revision in Dockerfile, with Gradio 5.49.1 selected for validation;
complete dependency resolution remains pending. The deployed environment must be
reviewed before use with important accounts.

Chromium runs as a non-root user inside a container with its own browser sandbox
disabled for container compatibility; browser web security is kept enabled. This
is not a hardened general browsing appliance. The Docker socket is not mounted
into the application containers. Only the authenticated gateway has a host port;
Ollama, raw VNC and CDP have no published host ports.

Upstream: https://github.com/browser-use/web-ui at
61962296c38a0d064e0ba02c827192b7a81d1819. Upstream code and license are fetched
unchanged during build, then the explicit patch and overlay are applied. Ollama
0.33.3 is pinned; individual model licenses remain applicable.
