"""Run with Python 3: check, init, start, status, stop, credentials, or smoke."""
import argparse
import json
import os
from pathlib import Path
import secrets
import shutil
import string
import subprocess
import sys
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]


def run(*args, **kwargs):
    return subprocess.run(list(args), cwd=ROOT, check=True, **kwargs)


def resources():
    memory = int(Path("/proc/meminfo").read_text().split("MemTotal:")[1].split()[0]) * 1024
    for file in ("/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory/memory.limit_in_bytes"):
        try:
            limit = Path(file).read_text().strip()
            if limit != "max":
                memory = min(memory, int(limit))
        except (OSError, ValueError):
            pass
    return memory / 2**30, shutil.disk_usage(ROOT).free / 2**30


def check():
    memory, disk = resources()
    print(json.dumps({"ram_gib": round(memory, 1), "free_disk_gib": round(disk, 1),
                      "cpu_count": os.cpu_count(), "docker_installed": bool(shutil.which("docker"))}, indent=2))
    if not shutil.which("docker"):
        raise SystemExit("Docker is not installed. A Codespace with the supplied devcontainer installs it.")
    run("docker", "compose", "version")
    run("docker", "info", "--format", "{{.ServerVersion}}")
    if memory < 5.5:
        raise SystemExit("This full stack needs at least approximately 6 GB RAM; choose another server.")
    if disk < 12:
        raise SystemExit("Less than 12 GiB disk is free. Inspect storage before downloading images or models.")
    if os.getenv("CODESPACES"):
        print("Codespaces: project development/testing only. Check remaining compute AND GB-month quota first.")
    return memory


def init():
    memory = check()
    if os.getuid() == 0:
        raise SystemExit("Initialize as your normal Docker-enabled user so profile permissions match the non-root container.")
    if (ROOT / ".env").exists() or (ROOT / ".secrets").exists():
        raise SystemExit("Existing settings retained. Do not reinitialize; use start or inspect .env.")
    password = secrets.token_urlsafe(24)
    digest = run("docker", "run", "--rm", "-i", "caddy:2.10.2-alpine", "caddy", "hash-password",
                 input=password + "\n", text=True, capture_output=True).stdout.strip()
    if not digest.startswith("$2"):
        raise SystemExit("Caddy did not return a bcrypt hash; no settings were written.")
    previous_umask = os.umask(0o077)
    try:
        private = ROOT / ".secrets"
        private.mkdir()
        (private / "users.caddy").write_text("agent " + digest + "\n")
        vnc = "".join(secrets.choice(string.ascii_letters + string.digits) for _ in range(8))
        (private / "vnc_password").write_text(vnc + "\n")
        (private / "credentials.txt").write_text(f"Username: agent\nWeb password: {password}\nVNC password: {vnc}\n")
        (ROOT / ".local-state/browser/work").mkdir(parents=True)
        (ROOT / ".local-state/browser/profile").mkdir()
        (ROOT / ".local-state/ollama").mkdir()
        model = "qwen2.5:3b" if memory >= 7 else "qwen2.5:1.5b"
        (ROOT / ".env").write_text(
            f"OLLAMA_MODEL={model}\nAPP_UID={os.getuid()}\nAPP_GID={os.getgid()}\n"
            f"MODEL_MEMORY={'4g' if memory >= 7 else '3g'}\nMODEL_THREADS=2\nWEB_PORT=8080\n")
    finally:
        os.umask(previous_umask)
    # Secrets remain unreadable to other host users. The browser container runs at this UID.
    print(f"Initialized {model}. Use 'credentials' in your own terminal to view login details.")


def setting(name):
    for line in (ROOT / ".env").read_text().splitlines():
        key, _, value = line.partition("=")
        if key == name:
            return value
    raise SystemExit(f"Missing setting {name}; run init first.")


def start():
    check()
    if not (ROOT / ".env").exists():
        raise SystemExit("Run init first.")
    run("docker", "compose", "config", "--quiet")
    run("docker", "compose", "up", "-d", "--wait", "--wait-timeout", "120", "ollama")
    run("docker", "compose", "exec", "-T", "ollama", "ollama", "pull", setting("OLLAMA_MODEL"))
    run("docker", "compose", "up", "-d", "--build", "--wait", "--wait-timeout", "240")
    print("Started on 127.0.0.1:8080. Keep the Codespaces forwarded port PRIVATE; use its HTTPS link.")


def smoke():
    # Test protection before making any model or browser request.
    try:
        urllib.request.urlopen("http://127.0.0.1:8080/", timeout=10)
    except urllib.error.HTTPError as error:
        if error.code != 401:
            raise
    else:
        raise SystemExit("FAIL: gateway allowed an unauthenticated request")
    print("PASS: gateway requires authentication")
    run("docker", "compose", "exec", "-T", "browser", "python", "/app/deploy/healthcheck.py")
    run("docker", "compose", "exec", "-T", "browser", "python", "/app/deploy/model_check.py")
    print("Now run the README test command from the mobile WebUI to validate the complete agent.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["check", "init", "start", "status", "stop", "credentials", "smoke"])
    command = parser.parse_args().command
    try:
        if command in {"check", "init", "start", "smoke"}:
            globals()[command]()
        elif command == "credentials":
            print((ROOT / ".secrets/credentials.txt").read_text())
        elif command == "stop":
            run("docker", "compose", "stop")
            print("Containers stopped; saved profile retained. Stop the Codespace too to end compute usage.")
        else:
            run("docker", "compose", "ps")
    except subprocess.CalledProcessError as error:
        raise SystemExit(f"Command failed with exit code {error.returncode}. Inspect its output; saved data is retained.")
